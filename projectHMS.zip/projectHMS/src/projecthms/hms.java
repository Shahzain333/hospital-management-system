package projecthms;
import java.sql.*;


public class hms 
{
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
   //=======start connection 
    public hms(){
        try
        {
          Class.forName("com.mysql.cj.jdbc.Driver");
          con= DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
          st=con.createStatement();
          System.out.println("Data base is connected");
         
        }catch(Exception e)
        {
           System.out.println("Error in connection in hms"+e);
        }
    }
    //=======end connection
    
    //=======start login
    public ResultSet login(String user,String pass)
    {
        try 
        {
             String sql=" select * from login where username='"+user+"' and password='"+pass+"'";
             rs=st.executeQuery(sql);
            
        } catch (Exception e) {
            System.out.println("Error in login in hms"+e);
        }
        return rs;
    }
    //=======end login
    
   //========start insert all patient
 
    public void patient1(String pid,String pnm,String pfnm,String pno,String pcnic,String pgender,String pbg,int page,String paddress)
    {
        try 
        {
           String sql=" INSERT INTO `allpatient`(`ID`, `Name`, `FatherName`, `ContactNo`, `Cnic`, `Gender`, `BloodGroup`, `Age`, `Address`, `DoctorName`, `Date`, `Timing`) VALUES ('"+pid+"','"+pnm+"','"+pfnm+"','"+pno+"','"+pcnic+"','"+pgender+"','"+pbg+"','"+page+"','"+paddress+"') ";
           st.executeUpdate(sql);
        }catch(Exception ex)
        {
            System.out.println("Error in insert patient1 in hms"+ex);
        }
    }
    //========end insert all patient
    
    //=========start update patient  
       public String patient4(String pid,String pnm,String pfnm,String pno,String pcnic,String pgender,String pbg,int page,String paddress){
           String sql ="UPDATE `allpatient` SET ID='"+pid+"',Name='"+pnm+"',FatherName='"+pfnm+"',ContactNo='"+pno+"',Cnic='"+pcnic+"',Gender='"+pgender+"',BloodGroup='"+pbg+"',Age='"+page+"',Address='"+paddress+"' WHERE ID='"+pid+"'" ;
           try {
                st.executeUpdate(sql);
        } catch (Exception e) {
               System.out.println("Error in update patient4 in hms"+ e);
        }
           return sql;
       }
    //=========end update patient 
       
    //========start delete patient
       
       public void patient5(String pid ){
        try {
            
            String sql="delete from allpatient where ID='"+pid+"'";
            st.executeUpdate(sql);
           
        } catch (Exception e) {
            
            System.out.println("Erorr in delete patient5 in hms"+e);
        }
       }
    //========end delete patient
    
    //========start patient show data in form
       
       public  ResultSet get1(String pid) {
           String sql = "SELECT * FROM allpatient WHERE ID = '"+ pid +"' ";
           try {
                rs = st.executeQuery(sql);
        } catch (Exception ex) {
              System.out.println("Error in resultset in get1 in hms"+ex);  
        }
           return rs;
       }
    //=========start patient show data in form
     
    //=========start patient data in table
       
       public ResultSet patient3(){
        
        
          String sql="select * from allpatient ";
        try{
          rs=st.executeQuery(sql);
        }catch(Exception e){
        System.out.println("Error in patient3 in hms"+e);
        }
        return rs;
    }
    //=========end patient data in table
       
    //=========Start total count patient data from data base table
      
       public ResultSet allpatient(){
      
          String sql="Select count(ID) from allpatient ";
       try{
               rs=st.executeQuery(sql);
         }catch(Exception e){
               System.out.println("Error in allpatient in hms"+e);
          }
          return rs;
       }
    //=========End total count patient data from data base table
       
    //========start insert all doctor
       public void doctor1(String did,String dnm,int dage,String dgender,String daddress,String dcnic,String dno,String a,String dcity,String dbg,String b,int dfee,String djd,String dld,String dvt,String ddays)
       {
           try 
           {
              String sql="insert into alldoctor (ID,Name,Age,Gender,Address,Cnic,ContactNo,MaterialStatus,City,BloodGroup,Department,Fees,JoiningDate,LeavingDate,VisitTime,Days) values ('"+ did + "','"+dnm+"','"+dage+"','"+dgender+"','"+daddress+"','"+dcnic+"','"+dno+"','"+a+"','"+dcity+"','"+dbg+"','"+b+"','"+dfee+"','"+djd+"','"+dld+"','"+dvt+"','"+ddays+"' )";
              st.executeUpdate(sql);
           } catch (Exception e) 
           {
               System.out.println("Error in doctor1 in hms"+e);
           }
           
       }
    //=========end insert  doctor
     
    //=========start update  doctor
       
       public String doctor2(String did,String dnm,int dage,String dgender,String daddress,String dcnic,String dno,String a,String dcity,String dbg,String b,int dfee,String djd,String dld,String dvt,String ddays){
           String sql ="UPDATE alldoctor SET ID='"+did+"',Name='"+dnm+"',Age='"+dage+"',Gender='"+dgender+"',Address='"+daddress+"',Cnic='"+dcnic+"',ContactNo='"+dno+"',MaterialStatus='"+a+"',City='"+dcity+"',BloodGroup='"+dbg+"',Department='"+b+"',Fees='"+dfee+"',JoiningDate='"+djd+"',LeavingDate='"+dld+"',VisitTime='"+dvt+"',Days='"+ddays+"'   WHERE ID='"+did+"' ";
           try {
                st.executeUpdate(sql);
        } catch (Exception e) {
               System.out.println("Error in update doctor2 in hms"+ e);
        }
           return sql;
       }
    //=========end update doctor 
       
    //========start delete doctor
   
     public void doctor3(String did){
       try {
            
            String sql="delete from alldoctor where ID='"+did+"'";
            st.executeUpdate(sql);
            
        } catch (Exception e) {
            
            System.out.println("Erorr in delete doctor3 in hms"+e);
        }
       }
    //========end delete doctor    
    
    //=========start doctor show data in form  
     
     public ResultSet get2(String did){
           String sql = "SELECT * FROM alldoctor WHERE ID = '"+ did +"' ";
           try {
                rs = st.executeQuery(sql);
             
        } catch (Exception ex) {
              System.out.println("Error in resultset in get2 in hms"+ex);
        }
              return rs;
       }
     //=========end doctor show data in form  
     
     //=========start doctor data in table + show name in adnm combobox in appointment1
       
       public ResultSet doctor4(){
        
          String sql="select * from alldoctor ";
        try{
          rs=st.executeQuery(sql);
        }catch(Exception e){
        System.out.println("Error in doctor4 in hms"+e);
        }
        return rs;
    }
    //=========end doctor data in table + show name in adnm combobox in appointment1
    
    //=========Start total count doctor data from data base table
      
       public ResultSet alldoctor(){
      
          String sql="Select count(ID) from alldoctor ";
       try{
               rs=st.executeQuery(sql);
         }catch(Exception e){
               System.out.println("Error in alldoctor in hms"+e);
          }
          return rs;
       }
    //=========End total count doctor data from data base table
  
    //=========start insert appointment  doctor
       
       public void appointment1(String aid,String anm,String afnm,String ano,String agender,String c,String adate,String atime,String d){  
           try{
                String sql="INSERT INTO `allappointment`(`ID`, `Name`, `FatherName`, `ContactNo`, `Gender`, `DoctorName`, `AppointmentDate`, `AppointmentTiming`, `AppointmentDay`) VALUES ('"+aid+"','"+anm+"','"+afnm+"','"+ano+"','"+agender+"','"+c+"','"+adate+"','"+atime+"','"+d+"')";
                st.executeUpdate(sql);
           }catch(Exception e){
                System.out.println("Error in insert appointment1 in hms"+e);   
           }
       }

    //=========end insert appointment  doctor
       
    //========start patient appointment show data in form
       
       public  ResultSet get5(String aid) {
           String sql = "SELECT * FROM allappointment WHERE ID = '"+ aid +"' ";
           try {
                rs = st.executeQuery(sql);
        } catch (Exception ex) {
              System.out.println("Error in resultset in get5 in hms"+ex);  
        }
           return rs;
       }
    //=========start patient appointment show data in form
       
    //=========start update appointment  doctor
       
       public void appointment3(String aid,String anm,String afnm,String ano,String agender,String c,String adate,String atime,String d){  
           try{
                String sql="UPDATE `allappointment` SET `ID`='"+aid+"',`Name`='"+anm+"',`FatherName`='"+afnm+"',`ContactNo`='"+ano+"',`Gender`='"+agender+"',`DoctorName`='"+c+"',`AppointmentDate`='"+adate+"',`AppointmentTiming`='"+atime+"',`AppointmentDay`='"+d+"' WHERE ID='"+aid+"' ";
                st.executeUpdate(sql);
           }catch(Exception e){
                System.out.println("Error in update appointment3 in hms"+e);   
           }
       }

    //=========end update appointment  doctor
       
    //========start delete appointment
       
       public void appointment2(String aid ){
        try {
            
            String sql="delete from allappointment where ID='"+aid+"'";
            st.executeUpdate(sql);
           
        } catch (Exception e) {
            
            System.out.println("Erorr in delete appointment2 in hms"+e);
        }
       }
    //========end delete appointment
    
    //=========start show appointment data in table
       
       public ResultSet appointment2(){
        
          String sql="select * from allappointment ";
        try{
          rs=st.executeQuery(sql);
        }catch(Exception e){
        System.out.println("Error in appointment2 in hms"+e);
        }
        return rs;
    }
    //=========end show appointment data in table
       
    //=========Start total count appointment data from data base table
      
       public ResultSet allappointment2(){
      
          String sql="Select count(ID) from allappointment ";
       try{
               rs=st.executeQuery(sql);
         }catch(Exception e){
               System.out.println("Error in allappointment2 in hms"+e);
          }
          return rs;
       }
    //=========End total count appointment data from data base table
       
  //==========start insert in diagnosis in patient
       
      public void allpatientreport(String search,String psymptoms,String pdiagnosis,String pmedicine,String pdate,String ptime,String selection,String list){  
           try{
                String sql="INSERT INTO `patientreport`( ID,`Symptoms`, `Diagnosis`, `Medicine`, `Date`, `Time`, `Ward_Req`, `Type_ward`) VALUES ('"+search+"','"+psymptoms+"','"+pdiagnosis+"','"+pmedicine+"','"+pdate+"','"+ptime+"','"+selection+"','"+list+"')";
                st.executeUpdate(sql);
           }catch(Exception e){
                System.out.println("Error in insert allpatientreport in hms"+e);   
           }
       } 
       
  //==========end insert in diagnosis in patient
      
  //=========start update  daignosis
       
       public String allpatientreport2(String search,String psymptoms,String pdiagnosis,String pmedicine,String pdate,String ptime,String selection,String list){
           String sql ="UPDATE `patientreport` SET ID='"+search+"',`Symptoms`='"+psymptoms+"',`Diagnosis`='"+pdiagnosis+"',`Medicine`='"+pmedicine+"',`Date`='"+pdate+"',`Time`='"+ptime+"',`Ward_Req`='"+selection+"',`Type_Ward`='"+list+"' WHERE ID='"+search+"' ";
           try {
                st.executeUpdate(sql);
        } catch (Exception e) {
               System.out.println("Error in update allpatientreport in hms"+ e);
        }
           return sql;
       }
   //=========end update daignosis
       
    //========start delete daignosis
       
       public void allpatientreport3(String search ){
        try {
            
            String sql="delete from patientreport where ID='"+search+"'";
            st.executeUpdate(sql);
           
        } catch (Exception e) {
            
            System.out.println("Erorr in delete patientreport in hms"+e);
        }
       }
    //========end delete daignosis
       
   //========start patient show data in form
       
       public  ResultSet get4(String pid) {
           String sql = "SELECT * FROM patientreport WHERE ID = '"+ pid +"' ";
           try {
                rs = st.executeQuery(sql);
        } catch (Exception ex) {
              System.out.println("Error in resultset in get4 in hms"+ex);  
        }
           return rs;
       }
    //=========start patient show data in form
       
  //==========start show allpatient report data in table 
      public ResultSet allpatientreport2(){
          try{
              String sql="SELECT  allpatient.ID,allpatient.Name,allpatient.FatherName,allpatient.ContactNo,allpatient.Cnic,allpatient.Gender,allpatient.BloodGroup,allpatient.Age,allpatient.Address,patientreport.Symptoms,patientreport.Diagnosis,patientreport.Medicine,patientreport.Date,patientreport.Time,patientreport.Ward_Req,patientreport.Type_Ward\n" +
              "FROM allpatient, patientreport\n" +
              "WHERE allpatient.ID = patientreport.ID\n" +
              "ORDER BY allpatient.ID";
              rs=st.executeQuery(sql);
              
          }catch(Exception e){
              System.out.println("Error in allpatientreport2"+e);
          }
          return rs;
      }
  
  //==========start show allpatient report data in table  
      
  //=========Start total count patientreport from data base table
      
       public ResultSet allpatientreport3(){
      
          String sql="Select count(ID) from patientreport ";
       try{
               rs=st.executeQuery(sql);
         }catch(Exception e){
               System.out.println("Error in allpatientreport3 in hms"+e);
          }
          return rs;
       }
    //=========End total count patientreport from data base table

       public static void main(String [] args)
    {
        hms h=new hms();
    }
 
}    

    

